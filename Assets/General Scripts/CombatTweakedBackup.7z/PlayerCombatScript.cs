using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCombatScript : MonoBehaviour
{

    public Animator animator;
    public PlayerMovement Playermove;

    public Transform attackPoint;
    public float attackRange = 0.5f;
    public LayerMask enemyLayers;
    public int attackDamage = 40;

    public float attackRate = 2f;
    //float nextAttackTime = 0f;

    //float attackDamageTime = 0f;
    public float damagedelay = 0.25f;

    public int currentHealth;
    public int maxHealth = 100;

    int attackstate = 0;
    public float combobuffer = 0.1f;
    public float buffertime = 0f;
    bool wasAttacking = false;

    void Start()
    {
        currentHealth = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {


        if (!Playermove.attacking)
        {
            if(attackstate == 3)
            {
                attackstate = 0;
            }

            if (wasAttacking)
            {
                buffertime = combobuffer;
                wasAttacking = false;
            }

            if (Input.GetButton("Attack"))
            {
                wasAttacking = true;
                attackstate += 1;
                setAttackState(attackstate);
            }

        }

        buffertime -= Time.deltaTime;

        if (buffertime < 0)
        {
            attackstate = 0;
        }


    }
  
    void setAttackState(int state)
    {
        if (state == 1)
        {
            animator.SetBool("Attack1", true);
        }
        if (state == 2)
        {
            animator.SetBool("Attack2", true);
        }
        if (state == 3)
        {
            animator.SetBool("Attack3", true);
        }
    }


    public void Attack(float delay, int attackDamage)
    {
        Playermove.attacking = true;
        StartCoroutine(DelayAction(delay));
        if (Playermove.attacking)
        {
            Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayers);

            foreach (Collider2D enemy in hitEnemies)
            {
                Debug.Log("We hit " + enemy.name);
                enemy.GetComponent<Enemy>().TakeDamage(attackDamage);
            }
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
    }

    IEnumerator DelayAction(float delayTime)
    {
        //Wait for the specified delay time before continuing.
        yield return new WaitForSeconds(delayTime);
        //Do the action after the delay time has finished.
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }


}




