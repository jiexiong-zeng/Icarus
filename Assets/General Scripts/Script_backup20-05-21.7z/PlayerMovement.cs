using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController2D controller;
    public Animator animator;
    public Collider2D playerCollider;

    float horizontalMove = 0f;
    public float runSpeed = 40f;

    bool jump = false;
    public float jumpduration = 0.2f;
    float jumptime;

    public bool attacking;

    public float dashSpeed = 100f;
    bool dash = false;
    public float dashduration = 0.5f;
    float dashtime = 0f;
    float dashDirection = 0f;
    float invulnerableDuration = 0.2f;
    float invulnerableTime = 0f;

    bool block = false;

    // Update is called once per frame
    void Update()
    {
        playerCollider.enabled = true;

        horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;
        animator.SetFloat("Speed", Mathf.Abs(horizontalMove));

        jumptime -= Time.deltaTime;
        dashtime -= Time.deltaTime;
        invulnerableTime -= Time.deltaTime;

        if (Input.GetButtonDown("Jump") && !block && !attacking)
        {
            jumptime = jumpduration;
            animator.SetBool("Jumping",true);
        }
        if (jumptime > 0)
        {
            jump = true;
        }

        if (Input.GetButtonDown("Dash") && !jump && dashtime <= 0)
        {
            if (attacking)
            {
                attacking = false;
            }

            block = false;
            animator.SetBool("Block", false);
            dashtime = dashduration;
            invulnerableTime = invulnerableDuration;
            //dashDirection = Input.GetAxisRaw("Horizontal");
        }
        if (dashtime > 0)
        {
            dash = true;
        }
        if(invulnerableTime > 0)
        {
            playerCollider.enabled = false;
        }

        if (Input.GetButton("Block") && !dash)
        {
            block = true;
            animator.SetBool("Block", true);
        }
        else
        {
            block = false;
            animator.SetBool("Block", false);
        }

    }
    
    
    public void OnLanding ()
    {
    }

    void FixedUpdate()
    {
        animator.SetBool("Roll", false);


        if (attacking)
        {
            controller.Stop();
        }
        else if (block)
        {
            controller.Stop();
        }
        else if (dash)
        {
            if (controller.m_FacingRight)
            {
                dashDirection = 1;
            }
            else
            {
                dashDirection = -1;
            }
            controller.Move(dashDirection* dashSpeed* Time.fixedDeltaTime, false, false);
            animator.SetBool("Roll", true);
        }

        else
        {
            controller.Move(horizontalMove * Time.fixedDeltaTime, false, jump);
        }
        
        jump = false;
        dash = false;
        //crouch = false;
    }

}
